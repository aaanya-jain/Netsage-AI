# NetSage AI
AI-assisted Cisco-style network troubleshooting with mandatory human review.

## Required environment variable
`GEMINI_API_KEY`

## Run
```bash
pip install -r requirements.txt
streamlit run src/App.py
```

The project follows the supplied NetSage AI problem statement: 30 cases, structured AI diagnosis, deterministic checks, dashboard, and at least five human-corrected AI responses.
